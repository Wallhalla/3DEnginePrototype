#pragma once


class Cube