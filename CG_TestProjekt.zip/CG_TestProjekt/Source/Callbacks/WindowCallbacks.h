#pragma once
#include "GLFW/glfw3.h"


namespace CG
{
	void OnWindowResize(
		GLFWwindow* resizedWindow, 
		GLsizei newWidth, 
		GLsizei newHeight);
};